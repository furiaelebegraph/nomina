@extends('scaffold-interface.layouts.app')
@section('title','Show')
@section('content')
<section class="content">
    <h1>Show <?php echo e($parser->singular()); ?></h1>
    <br>
       <a href='{!!url("<?php echo e($parser->singular()); ?>")!!}' class = 'btn btn-primary'><i class="fa fa-home"></i><?php echo e($parser->upperCaseFirst()); ?> Index</a>
    <br>
    <table class = 'table table-bordered'>
        <thead>
            <th>Key</th>
            <th>Value</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dataSystem->dataScaffold('v'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <b><?php echo e($value); ?></b>
                </td>
                <td>{!!$<?php echo e($parser->singular()); ?>-><?php echo e($value); ?>!!}</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($dataSystem->getRelationAttributes() != null): ?>
            <?php $__currentLoopData = $dataSystem->getRelationAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $value1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <b><i><?php echo e($value1); ?> : </i></b>
                </td>
                <td>{!!$<?php echo e($parser->singular()); ?>-><?php echo e(str_singular($key)); ?>-><?php echo e($value1); ?>!!}</td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
</section>
@endsection

<?php $__env->startComponent('mail::message'); ?>
# Hola! Para verificar tu correo

<?php $__env->startComponent('mail::button', ['url' => route('enviarCorreoListo',['correo' => $usuario['correo'], 'emailtoken' => $usuario['emailtoken'] ])]); ?>
DA CLICK AQUI!
<?php echo $__env->renderComponent(); ?>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>

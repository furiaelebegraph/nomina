//<?php echo e($parser->singular()); ?> Routes
Route::group(['middleware'=> 'web'],function(){
  Route::resource('<?php echo e($parser->singular()); ?>','<?php if(config('amranidev.config.controllerNameSpace')): ?>\<?php echo e(config('amranidev.config.controllerNameSpace')); ?>\<?php endif; ?><?php echo e(ucfirst($parser->singular())); ?>Controller');
  Route::post('<?php echo e($parser->singular()); ?>/{id}/update','<?php if(config('amranidev.config.controllerNameSpace')): ?>\<?php echo e(config('amranidev.config.controllerNameSpace')); ?>\<?php endif; ?><?php echo e(ucfirst($parser->singular())); ?>Controller@update');
  Route::get('<?php echo e($parser->singular()); ?>/{id}/delete','<?php if(config('amranidev.config.controllerNameSpace')): ?>\<?php echo e(config('amranidev.config.controllerNameSpace')); ?>\<?php endif; ?><?php echo e(ucfirst($parser->singular())); ?>Controller@destroy');
  Route::get('<?php echo e($parser->singular()); ?>/{id}/deleteMsg','<?php if(config('amranidev.config.controllerNameSpace')): ?>\<?php echo e(config('amranidev.config.controllerNameSpace')); ?>\<?php endif; ?><?php echo e(ucfirst($parser->singular())); ?>Controller@DeleteMsg');
});

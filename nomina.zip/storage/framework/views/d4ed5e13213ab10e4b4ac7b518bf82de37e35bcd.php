<?php $__env->startSection('title','Create'); ?>
<?php $__env->startSection('content'); ?>

<section class="content">
    <h1>
        Create usuario
    </h1>
    <a href="<?php echo url('usuario'); ?>" class = 'btn btn-danger'><i class="fa fa-home"></i> Usuario Index</a>
    <br>
    <form method = 'POST' action = '<?php echo url("usuario"); ?>'>
        <input type = 'hidden' name = '_token' value = '<?php echo e(Session::token()); ?>'>
        <div class="form-group">
            <label for="nombre">nombre</label>
            <input id="nombre" name = "nombre" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="correo">correo</label>
            <input id="correo" name = "correo" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="password">password</label>
            <input id="password" name = "password" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="telefono">telefono</label>
            <input id="telefono" name = "telefono" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="verificado">verificado</label>
            <input id="verificado" name = "verificado" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="direccion">direccion</label>
            <input id="direccion" name = "direccion" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label for="nss">nss</label>
            <input id="nss" name = "nss" type="text" class="form-control">
        </div>
        <button class = 'btn btn-success' type ='submit'> <i class="fa fa-floppy-o"></i> Save</button>
    </form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('scaffold-interface.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
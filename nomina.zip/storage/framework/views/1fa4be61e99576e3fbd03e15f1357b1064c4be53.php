<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Registrarme')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('registroUsuarios')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nombre" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre')); ?></label>

                            <div class="col-md-6">
                                <input id="nombre" type="text" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="nombre" value="<?php echo e(old('nombre')); ?>" required autofocus>

                                <?php if($errors->has('nombre')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nombre')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="correo" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Cuenta de correo')); ?></label>

                            <div class="col-md-6">
                                <input id="correo" type="correo" class="form-control<?php echo e($errors->has('correo') ? ' is-invalid' : ''); ?>" name="correo" value="<?php echo e(old('correo')); ?>" required>

                                <?php if($errors->has('correo')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('correo')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="direccion" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Direccion')); ?></label>

                            <div class="col-md-6">
                                <input id="direccion" type="direccion" class="form-control<?php echo e($errors->has('direccion') ? ' is-invalid' : ''); ?>" name="direccion" value="<?php echo e(old('direccion')); ?>" required>

                                <?php if($errors->has('direccion')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('direccion')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="telefono" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Telefono')); ?></label>

                            <div class="col-md-6">
                                <input id="telefono" type="telefono" class="form-control<?php echo e($errors->has('telefono') ? ' is-invalid' : ''); ?>" name="telefono" value="<?php echo e(old('telefono')); ?>" required>

                                <?php if($errors->has('telefono')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('telefono')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="nss" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Numero Seguro Social')); ?></label>

                            <div class="col-md-6">
                                <input id="nss" type="nss" class="form-control<?php echo e($errors->has('nss') ? ' is-invalid' : ''); ?>" name="nss" value="<?php echo e(old('nss')); ?>" required>

                                <?php if($errors->has('nss')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('nss')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>